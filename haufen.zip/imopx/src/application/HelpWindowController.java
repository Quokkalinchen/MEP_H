package application;

import javafx.fxml.FXML;

public class HelpWindowController { 
    
  public Main help;
    
    public void setMain(Main help){
        this.help = help;
    }
}
