package Programm;

import java.io.File;

public class ImpoXiStart implements Runnable{
	public static int fileCounter=0;
	public static  int progressCounter=0;
	private String dbUser;
	private String dbIp;
	private String dbPw;
	private String dbName;
	public File dataPath;
	public File[] data;
	Extractor cr = new Extractor();

	
	public void run(){
		
	
		data = dataPath.listFiles();
		//Extractor cr = new Extractor();
		cr.connectToMysql(dbIp,dbName,dbUser,dbPw);
		
		if(dataPath != null && !dataPath.equals("")){
			for(int i=0; i<data.length; i++){
				if(data[i].getAbsolutePath().endsWith("CSV")){
					String strPath[]=cr.createTable(data[i].getAbsolutePath(),';');
					cr.insertInto(data[i].getAbsolutePath(),';', strPath);
				}
				
			}
			
		}
	
				
		//cr.dropTables();
		
	}
	public  ImpoXiStart(File pathData, String dbUser, String dbIp, String dbPw, String dbName) {
		
		this.dbUser = dbUser;
		this.dbIp = dbIp;
		this.dbPw = dbPw;
		this.dbName = dbName;

		this.dataPath = pathData;

		data = dataPath.listFiles();
		if (dataPath != null && !dataPath.equals("")) {
			for (int i = 0; i < data.length; i++) {
				if (data[i].getAbsolutePath().endsWith("CSV")) {
					fileCounter++;
				}

			}

		}
	}

}
